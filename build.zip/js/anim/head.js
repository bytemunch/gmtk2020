import AnimationPart from "./animationPart.js";
import AnimEye from "./eye.js";
import { DEBUG } from "../main.js";
export default class AnimHead extends AnimationPart {
    constructor(w, h) {
        super(w, h);
        this.rotation = 0;
        this.eye = this.addPart(new AnimEye(h / 3, h / 3));
    }
    draw() {
        this.ctx.clearRect(0, 0, this.cnv.width, this.cnv.height);
        this.ctx.translate(this.cnv.width / 2, this.cnv.height / 2);
        this.ctx.fillStyle = 'black';
        this.ctx.fillRect(-this.width / 2, -this.height / 2, this.width, this.height);
        this.ctx.strokeStyle = 'white';
        this.ctx.strokeRect(-this.width / 2, -this.height / 2, this.width, this.height);
        this.ctx.drawImage(this.eye.cnv, this.width / 6, -this.height / 4);
        this.ctx.setTransform(1, 0, 0, 1, 0, 0);
        if (DEBUG.BOUNDING_BOXES)
            this.drawBB();
    }
}
//# sourceMappingURL=head.js.map