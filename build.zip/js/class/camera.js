export default class Camera {
    constructor() {
        this.x = 0;
        this.y = 0;
        this.width = 480;
        this.height = 320;
    }
    follow(object) {
        this.x = object.x - 200;
        this.y = object.y - 270;
    }
}
//# sourceMappingURL=camera.js.map