import { b2player } from "../main.js";
export default class InteractHint {
    constructor(x, y) {
        this.active = false;
        this.x = x;
        this.y = y;
    }
    act() {
        if (!this.active)
            return;
        this.action();
    }
    update() {
        this.x = b2player.x - 8;
        this.y = b2player.y - b2player.height;
    }
    draw(ctx, camera) {
        if (!this.active)
            return;
        ctx.strokeStyle = 'white';
        ctx.fillStyle = 'black';
        ctx.fillRect(this.x - camera.x, this.y - camera.y, 16, 16);
        ctx.strokeRect(this.x - camera.x, this.y - camera.y, 16, 16);
        ctx.fillStyle = 'white';
        ctx.font = '12px monospace';
        ctx.fillText('E', this.x + 4 - camera.x, this.y + 11 - camera.y);
    }
}
//# sourceMappingURL=interactHint.js.map